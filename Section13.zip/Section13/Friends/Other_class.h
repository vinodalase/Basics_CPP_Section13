#ifndef _OTHER_CLASS_H_
#define _OTHER_CLASS_H_

class Player;

class Other_class
{
public:
    void display_player(Player &p);
};

#endif // _OTHER_CLASS_H_
